# Web-Security
A repository to record my usual studies.

Some knowledge I learned from CTF, if you want to come to learn frontier technology, go around.

And Please ignore my poor English，Of course, for my own convenience, I may use Chinese in the specific file descriptions

# Preface

In the blink of an eye, half of the sophomore year has also passed, here learning web security is also close to half a year, this half-year stumble also gained a lot, intend to create a new warehouse to record the future learning situation, and collect some good information

&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Y4tacker

 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Recorded on Dec 27, 2020	



# Programming Languages

- [Programming Languages](https://github.com/Stakcery/Web-Security/tree/main/ProgrammingLanguages)
  - Description:A branch for documenting security issues in programming languages,such as Java、Python、PHP、Nodejs、SQL and so on.

# Middleware

- [Middleware](Middleware)
  - Description:A branch for documenting middleware security issues

# JWT

- [JsonWebToken](https://github.com/Stakcery/Web-Security/tree/main/JWT)
  - Description:A branch for documenting some security issues about jwt.

# SSRF

- [Server-Side Request Forgery](https://github.com/Stakcery/Web-Security/tree/main/SSRF)
  - Description:A branch for documenting some security issues about ssrf.

# SSTI

- [Server-side template injection](https://github.com/Stakcery/Web-Security/tree/main/SSTI)
  - Description:A branch for documenting some security issues about ssti.

# XXE

- [XML External Entity Injection Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/XXE)
  - Description:A branch for documenting some security issues about xxe.

# Penetration test

- [Penetration Testing Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/PenetrationTest/vulnstack)
  - Description: A branch for documenting penetration testing study materials

# Blockchain

- [Blockchain Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/Blockchain)
  - Description: A branch for documenting blockchain study materials，though it is not belong to web application, but just for fun.

# Bypass-disable-functions

- [Bypass-disable-functions](https://github.com/Stakcery/Web-Security/tree/main/Bypass-disable-functions)
  - Description:Bypass-disable-functions

# Unserialize

- [Unserialize](https://github.com/Stakcery/Web-Security/tree/main/Unserialize) 
  - Description:A branch for documenting something about unserialize.

# WP

- [Write-up for training](https://github.com/Stakcery/Web-Security/tree/main/WP)
  - Description:  A branch for documenting my training

# Link Sharing

- [PayloadsAllTheThings](https://github.com/swisskyrepo/PayloadsAllTheThings)
  - Description:A list of useful payloads and bypasses for Web Application Security.