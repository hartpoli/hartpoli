# Unserialize

## PHP

- [PHP-Unserialize](https://github.com/Stakcery/Web-Security/tree/main/Unserialize/PHP)
  - Description: 一些关于PHP反序列化的总结

