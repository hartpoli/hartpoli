# SSTI--Jinja2

- [SSTI-Jinja2-Bypass](https://github.com/Stakcery/Web-Security/blob/main/SSTI/jinja2/data/SSTI-Jinja2-Bypass.md)
  - Description:自己总结的SSTI的介绍与一些Trick

## 分享一些很好的文章，当然为了怕丢失顺便把mhtml格式转存了

[Jinja2官方文档，可以深入学习获得新姿势](https://jinja.palletsprojects.com/en/2.11.x/templates/)

[SSTI模板注入及绕过姿势(基于Python-Jinja2)(基础篇)](https://blog.csdn.net/solitudi/article/details/107752717?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522160992724816780274016446%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=160992724816780274016446&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_v2~rank_v29-1-107752717.pc_v2_rank_blog_default&utm_term=ssti&spm=1018.2226.3001.4450)

[SSTI模板注入绕过（进阶篇）](https://blog.csdn.net/miuzzx/article/details/110220425?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522160992639516780263058545%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=160992639516780263058545&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_v2~rank_v29-1-110220425.pc_v2_rank_blog_default&utm_term=ssti&spm=1018.2226.3001.4450)