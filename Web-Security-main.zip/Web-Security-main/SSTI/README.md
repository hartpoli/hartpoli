# SSTI

- [Jinja2](https://github.com/Stakcery/Web-Security/tree/main/SSTI/jinja2)
  - Description:Based on jinja2 template engine.

- [Smarty](https://github.com/Stakcery/Web-Security/tree/main/SSTI/smarty)
  - Description:Based on Smarty template engine.

- [Twig](https://github.com/Stakcery/Web-Security/tree/main/SSTI/twig)
  - Description:Based on Smarty twig engine.



# Link Sharing

[一篇文章带你理解漏洞之 SSTI 漏洞](https://www.k0rz3n.com/2018/11/12/%E4%B8%80%E7%AF%87%E6%96%87%E7%AB%A0%E5%B8%A6%E4%BD%A0%E7%90%86%E8%A7%A3%E6%BC%8F%E6%B4%9E%E4%B9%8BSSTI%E6%BC%8F%E6%B4%9E/#2-Twig)