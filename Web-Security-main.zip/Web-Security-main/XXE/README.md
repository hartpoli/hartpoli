# XXE

- [What is xxe?](https://xz.aliyun.com/t/3357)
  - Descripotion:一篇文章带你深入理解漏洞之 XXE 漏洞(觉得写的不错诶)
- [A simple CTF question](https://github.com/Stakcery/Web-Security/blob/main/XXE/data/%5BCTFSHOW%5DWEB373.md)
  - Description:一道最简单的题帮你熟悉XXE
- [XXE with No return display](https://github.com/Stakcery/Web-Security/blob/main/XXE/data/%E6%97%A0%E5%9B%9E%E6%98%BE.md)
  - Description:无回显实现带外输出
-  [Bypass by using exotic encodings](https://github.com/Stakcery/Web-Security/blob/main/XXE/data/%E7%BC%96%E7%A0%81%E7%BB%95%E8%BF%87.md)
  - Descripotion: Use UTF-16、UTF-32 and EBCDIC instead of UTF-8 to bypass.
- [Bypass by using different encodings](https://lab.wallarm.com/xxe-that-can-bypass-waf-protection-98f679452ce0/)
  - Description:Use two different encodings to bypass.
  - Add: Here are many ways on xxe bypass
  - [Chinese Translation](https://xz.aliyun.com/t/4059?accounttraceid=04ba92e87b2342b9a14daca5812cc52aoxob):那个是英文版的，发现了中文版

# Link Sharing

[Xml官方文档](https://www.w3.org/TR/xml/#sec-guessing)

[XXE that can Bypass WAF Protection](https://lab.wallarm.com/xxe-that-can-bypass-waf-protection-98f679452ce0/)