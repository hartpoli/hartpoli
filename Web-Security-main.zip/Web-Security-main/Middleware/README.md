# Middleware

## Nginx

- [Nginx](https://github.com/Stakcery/Web-Security/tree/main/Middleware/Nginx)
  - Desciption:Nginx related security issues

# Other

- [Other](https://github.com/Stakcery/Web-Security/tree/main/Middleware/Other)
  - Desciption:其他信息，比如Web中间件漏洞之类的，额找不到描述了