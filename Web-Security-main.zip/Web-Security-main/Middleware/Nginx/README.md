# Nginx

## Configuration Related

- [NginxSecurityConfigurations](https://github.com/Stakcery/Web-Security/blob/main/Middleware/Nginx/data/NginxSecurityConfigurations.md)

  ​	Description：Nginx相关的安全配置