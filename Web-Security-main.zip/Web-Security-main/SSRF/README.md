# SSRF

- [What is SSRF?](https://github.com/Stakcery/Web-Security/blob/main/SSRF/data/SSRF%E7%AE%80%E8%A6%81%E4%BB%8B%E7%BB%8D.md)
  - Description: A brief introduction to ssrf.

+ [Learn some simple bypasses from CTFSHOW](https://github.com/Stakcery/Web-Security/blob/main/SSRF/data/CTFSHOW-SSRF-WP.md)
  - Description:Learning SSRF from the CTFSHOW platform

+ ([Blackhat A-New-Era-Of-SSRF-Exploiting-URL-Parser-In-Trending-Programming-Languages.pdf](https://www.blackhat.com/docs/us-17/thursday/us-17-Tsai-A-New-Era-Of-SSRF-Exploiting-URL-Parser-In-Trending-Programming-Languages.pdf))
  - Description: Written by Orange Tsai