# PHP

- [Some tricks in  php](https://github.com/Stakcery/Web-Security/blob/main/ProgrammingLanguages/PHP/data/php%E7%9A%84%E4%B8%80%E4%BA%9B%E5%B0%8Ftrick.md) 
  - Description: Some tricks in the php language