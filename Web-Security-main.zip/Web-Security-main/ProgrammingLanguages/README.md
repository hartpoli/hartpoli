# ProgrammingLanguages

## Java

[Java Security Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/ProgrammingLanguages/Java)

- Description:A branch for documenting java security study topics.



## PHP

- [PHP Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/ProgrammingLanguages/PHP)
- Description:A branch for documenting php security study topics.



## Nodejs

- [Nodejs Mini Notes](https://github.com/Stakcery/Web-Security/tree/main/ProgrammingLanguages/Nodejs)
  - Description:A branch for documenting nodejs vulnerability study topics.

## SQL

- to be continued
