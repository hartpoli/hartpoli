# Java
- [Java Security Discussion By phith0n](https://github.com/phith0n/JavaThings)
  - Description: Java security learning of the essay written by phith0n
- [JAVA反序列化漏洞过程分析及调试](https://github.com/Stakcery/Web-Security/blob/main/ProgrammingLanguages/Java/data/unserialize/JAVA%E5%8F%8D%E5%BA%8F%E5%88%97%E5%8C%96%E6%BC%8F%E6%B4%9E%E8%BF%87%E7%A8%8B%E5%88%86%E6%9E%90%E5%8F%8A%E8%B0%83%E8%AF%95.mhtml)
