# Blockchain

- [[WP]CTFSHOW-Web379](https://github.com/Stakcery/Web-Security/blob/main/Blockchain/data/CTFSHOW-Web379.md)
  - Description:从一道题中了解了一点区块链的知识，不多但有点好玩