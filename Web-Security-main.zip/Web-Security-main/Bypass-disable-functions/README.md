# Bypass-disable-functions

这个没必要班门弄斧，放上一些连接即可

[浅谈几种Bypass disable_functions的方法](https://www.mi1k7ea.com/2019/06/02/%E6%B5%85%E8%B0%88%E5%87%A0%E7%A7%8DBypass-disable-functions%E7%9A%84%E6%96%B9%E6%B3%95)



# 仓库(exp)

https://github.com/mm0r1/exploits

https://github.com/l3m0n/Bypass_Disable_functions_Shell