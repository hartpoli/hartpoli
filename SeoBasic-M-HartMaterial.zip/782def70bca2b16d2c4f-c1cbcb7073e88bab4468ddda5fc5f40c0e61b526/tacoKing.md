




***************************************************************
SEO BASICS

If we sat down and analyzed why your friend's sites are ranking, the factors contributing to that would be : quality backlinks, good content, structured and consistent markup, meta-formats (if those are used), sitemaps, RSS feeds, social media integration (hate to even mention that one). Redirecting index.php to / wouldn't make the list.





Most of those areas are pretty straight forward. 

Structured and consistent markup usually gets billed as Semantic Markup. The condensed version of that is to use the correct HTML tags for your content. Like don't put the title of the article in a DIV, use an H1/H2 tag. With HTML5, put navigation elements into NAV tags, put the article into an ARTICLE tag, etc. 

Sitemaps, having an XML sitemap gives you some control over what SE bots index and when. 

RSS feeds for articles is probably going down in importance. Setup properly, the site should 'ping' or notify a central server that it has new content. SEs would then know to check your feed and site for the new content. 

Social media, just the obvious stuff. You post a new article, post it on the SM sites. 

I said meta-formats, it should have been micro formats. Simple explanation is these are tags/attributes added to the markup for specific types of structured content.  Some examples, Calendars, Products, Press Releases, etc. Those things have a standard structure and if you add the markup, it makes it easier for SEs to index your data. 

Can see here for more info : http://microformats.org/about

Here's some examples from google : 

https://support.google.com/webmasters/answer/146897?hl=en



TAKEAWAY = index.php vs. / , you control the largest link producer for your site so it's your choice what they link to. Most of the links for domain.com/ or domain.com/index.php will be on your site, not linked from outside sources. 


******************************************************************************************


HTACCESS RULES 

This rule :

RewriteCond %{HTTP_HOST} !^www.mydomain.com$ [NC]

RewriteRule .*$ http://www.mydomain.com/$1 [R=301,QSA,L]

forces www. even if they access it via domain.com . See here :

http://www.sitepoint.com/getting-started-apache-mod_rewrite-methods/

The QSA means to append the query string.

This part :

RewriteCond %{HTTP_REFERER} evildomain.com [NC]

RewriteRule .* - [F]

Looks like it prevents access if the referrer is evildomain.com

Can see it further examples of that here : http://perishablepress.com/stupid-htaccess-tricks/#sec9

mydomain.com/index.php and mydomain.com are the same thing by default. Unless you changed the default index handler. They should show up as two different requests though. I can't imagine why you would want to redirect index.php to / . If you don't want index.php showing up in the reports, change your links from index.php to just / in the href of Anchor elements.




*********************************************************************************

ISSUE TRACKER 

Here's a list of bug trackers you can host on your own webhost/server.

http://www.thegeekstuff.com/2010/08/bug-tracking-system/

I don't know which of those supports Feature requests though. You might be better off with a Ticket Support system. Like http://osticket.com/


*************************************************************************************

PROJECT IS DONE - Business

would dump the database, download/zip the CMS files. Provide version info for PHP/MySQL/Any other pertinent info. Email it to said client along with a note that it's X per hour for additional support. 




*************************************************************************************
Requirements:  Provide version info for PHP/MySQL/Any other pertinent info.


*************************************************************

relational model for Portfolio


A brief one, shouldn't be a high load so you can just build a simple model.

Project (each portfolio item is a project)

fields : project_id,project_name (varchar(32 or 64)),description (text), URL (varchar 128)

Services would be a simple service_id,service_name table, doesn't have to be a table though.

services_to_project- srtp_id,service_id,project_id

tags gets its own table, tag_id,tag_name(or tag_text).

tags_to_project table - ttp_id,tag_id, project_id

screenshots table - image_location,img_id,img_name,img_caption

screenshots_to_projects - stp_id,img_id, project_id

colors is the only thing left and it depends if you want to create palettes or just include a list of colors.

palettes - pal_id,pal_name,pal_description

colors - color_id,color_name,color_hex,color_rgb

colors_to_palette- ctp_id,color_id,palette_id

Pretty sure you can get a better Tags table structure by just searching google for a php build a tagging system tutorial. 


******************************************************************************************************
###Everything Package 


* Total number of pages (guess)
* How many page types (archetypes )

Special media requirements :

* image galleries
* media management
* video usage level ?

What content is needed and who will deliver by when?
Include Commerce emails (order,tracking,etc) and new user welcome email (branding should cover this as well)




####  Hosting requirements 

 Platform : 
 
 * OS : Linux/FreeBSD/Windows
 * webserver : apache/nginx/iis
 * server side language : php/aspx/ruby/
* front end framework : foundations/bootstrap
* javascript library : jQuery
* Database : MySQL 
*  Email Server :
*  Image server:
 * CMS/Scripts : 
 
 Multiple servers / Scalable Architecture  if required
 
* averages per hour/day/week/month
* peak usage  per hour/day/week/month
* \# of concurrent users
* projected storage space per user :  <MB , >10MB 

frequency/volume of email
budgeted for hosting this quarter?

Need a CDN?



What analytical tracking will be needed ?
Is GA good enough?
Will A/B or multivariate testing be employed?



######Design :

* Will there be a need for speciality content like pricing tables ?
* How many sales landing pages will be needed (frontpage counts as one)?
* Number of expected revisions. 
* Color Palette
* Mobile optimized or Responsive Template ?
* Is mobile a concern or not?
* UI Effects Front end (AJAX submissions, Transitions etc)





######SEO 

* site/url structure optimized for search engines

* inbound link building is outside scope 

* SEFU for above

* Need the ability to deliver,promote and track Promotions within the site?


######Customer Service will be handled how? 

* What documentation will be web based ?
* How are support issues resolved? Does it require a web component? ie support chat, ticketing system, etc.

######Commerce

* What level of security is required ?
* What payment processors/gateways will be utilized?
* SSL is assumed for all commerce.
* How will accessories be handled?
* Will discounts be required?
* Handling of bundles/term discounts etc.
* Total # of products.


######Backup Plan 

* Frequency of backups laid out including potential costs for storage.
* The actual plan to restore which must be tested for the backups to be effective.
* If off-site storage is required. 



###### Other
Any additional 3rd parties which have to be integrated into the system?




Automated actions (importing/exporting/transmitting files)
Integration with existing accounting solutions.
Required levels of Reporting

Forms submitted by users/clients/customers outside of the commerce scope


Mailing list management, email capture and schedule for email newsletter or promotions.

 Will Press Releases be distributed through the website? 
 Will News be posted to the site?
 Does it need a blog? Both of the above count as a blog.
 
 
 
Application Requirements

* CRUD Objects
* User levels
* User Roles
* API - internal use only
* API - public access point

Workflow Layouts (Approval of documents, annotation , proofing ,etc)
Revision Control for Documents

Data import 





{Existing Site Issues }
Saving URLs, preventing SEO damage














**************************************************************
PHP Access Control 


Libraries : 

http://phpacl.sourceforge.net/

http://sourceforge.net/projects/tackle/

http://phpgacl.sourceforge.net/


**************************************************************

Designer Workflow 

Are you producing PSD designs or working from something more than wireframes?

What tools do you already use? GIT is good for code. Less so for media resources.

about those tools, are you using a frontend framework? If so which ones? jQuery is assumed. Any specific plugins? Do you try to reuse the same ones, have you standardized the choice?

Which CMS or Framework do you use? Do you use others for speciality sites? Do you develop web applications along with web sites? Mobile App development?

Do you have a requirement to backup client work, either in progress or from the web? Is your backup plan just DropBox?

How many projects do you have open at one time? Do you have a development/staging server setup already (VPS or Dedicated).



*************************************************************************************



*************************************************************************************






























*************************************************************************************
PHP PDF Form w/ debugging 


You will be in over your head. 

PHP has a pdf library but you would have to template your existing format into, test print it, etc. All of which will take time. Learning the basics of the library isn't overly complicated but matching an existing document might be hard for your skill level. There's other options but I'm sticking with the 'build template for pdf, add values, export/save' method.

Plus the fact you should build this as a CRUD application so you can review the submissions if needed. **Do you know what CRUD is and how it applies here?**

Authorization, guessing it's a **single user application**. You could get by with a file based login system for yourself or using one of the existing php login scripts. Fastest way, just setup htpasswd (you can do that via CPanel or by hand). 

Let's get into the views present : 

* Customer Facing Web form
* admin login
* list view
* pdf template view
* pdf item view


**High level of processing.**

* Processing for Customer Facing Web form
* admin login
* functions for list view
* setting options (for the application)
* functions for item view

####Do we need to secure the PDFs? 

Back to the web form. We have to determine the fields for the form. Each of those has a type set so we can display the correct form input via code. Like Name is a text field type, State is a dropdown list. Which of those fields is required for successfully submission of the form (has to be communicated to the user).  Need to determine if you want AJAX submission or if standard will suffice. 

Need error states for that form too. These should look nice since they are public facing (right?).

#####Other point here: are you collecting SS#s? if so those should have more protection. At the very least base64 encode which you can decode on the server side.


{Explain CRUD HERE}

PDF template view should be added to tell the application/script/system which PDF template to use. Doing this will let you alter the PDF form output so you can have a 'safe' to use version and development copies.





###General Advice :

* Use a Front End Framework like bootstrap or foundation.
* Use PDO or a database library 
* Aura PHP is an option over using an entire PHP Framework


###links 
Front End Frameworks

* bootstrap : http://getbootstrap.com/ 
* foundation http://foundation.zurb.com/  
* Groundwork : http://groundwork.sidereel.com/
* HTML Kickstart : http://www.99lime.com/elements/
* YAML 4 : http://www.yaml.de/
* uiKit : http://www.getuikit.com/

PHP

* http://auraphp.com/  Aura
* http://auraphp.com/packages/Aura.Sql/1.3.0/   Aura SQL package 
* http://www.tcpdf.org/ tcPDF php library
* http://www.fpdf.org/ FPDF php library
* http://www.php-login.net/ php login script
* http://www.openwall.com/phpass/ PHPPass, covers security details



CRUD

* http://en.wikipedia.org/wiki/Create,_read,_update_and_delete 















**************************************************
####Executive Summary

*  due date
*  # of phases
*  deliverables
* Client deliverables + Due Dates
*  the project summary

Project Management takes over :

Segment Jobs 

####Design
* template archetypes needed
* mockups
* wireframes
* initial draft (comp ?)
* approved design
* any additional designs (adverts,promotions tied to this design)
* Document Design Elements 

#### Backend Development
* database model
* RDBMS or EAV
* user sub-system
* Application Requirements
* Platform setup
* Framework if required setup
* API (should be applicable)
* Write API 
* test API

#### Frontend Development
* select frameworks 
* determine URL structure
* build default page template (hdr/ftr-content)
* build each page archetype 
* template 
* test (browsers())
* Any Advanced UI ? consult() : skip;
* Build JS API reader

#### Copywriting
* like we have a copywriter

#### Marketing
* progress presentations for project

.......
##Phases

This method doesn't work so well without details.

### Journal

Day 1 : 

Do I have to hire contractors?

Yes: Get them started today. 

No: Get to work.

Are you using a CMS ? It's wordpress isn't it? Ok, that's, we'll just try to move forward.

Do you have a DEV server? Set it up if not.
Once it's setup, create a directory called PROJECT_NAME. Create a text file called readme.txt.
Write something smart in there. Save it. 

Establish objectives per phase per [insert word here for area of knowledge/skill but not domain or disclipine] 

###DESIGN Phase 1 
Sketch out the Site Structure. Map out the flow of the 

*  pages >
*  home > About 
* home> Products

Include category views and item detail views. Any forms which are public facing should be highlighted (put on a list). Forms which are restricted to specific users should be marked as well. Put that into the design folder and start working on a visual comp to present to the client. 

####Design Phase 1 Goal
* Produce Layouts
* Get approved Comps.

### FRONT END Phase 1
Setup DEV with frameworks. Create a default frontpage for the project (if application or other, *shrug* ). Build up sample data as placeholders (if you need chart data, tabular data, lists, whatever). If you are using a Template Engine, add it. Same for an autoloader. 
Determine URL structure for project site. If mod_rewrite is needed or not.  Create barebones of site from Layouts (provided by Design).

####FRONT END Phase 1 Goal
* Structure only site



### BACKEND Phase 1
Backend will provide Routing Information. 

Determine application requirements. Wireframe forms will be provided from design. 

Develop data model. Setup API framework , endpoint and testing protocol. 


####BACKEND Phase 1 Goal
* Routing requirements
* initial data model


## Client Delivery Phase 1
Client is provided with the design Comps, with selection being required for next phase (and payment milestone meet).



###DESIGN Phase 2 Goal

* Produce Comps for all required pages. 


###FRONT END Phase 2 Goal

* Convert Comps to pages.
* establish AJAX client for API contact


####BACKEND Phase 2 Goal
* Build API Server

## Client Delivery Phase 2
End of phase 2 present the Alpha version of the site. 



###DESIGN Phase 3 Goal
* Receive Client Feedback 
* Provide Final Revisions
* Browser Test Front End site


###FRONT END Phase 3 Goal
* Complete API integration 



####BACKEND Phase 3 Goal
* Test API Server
* Build  LIVE server environment 

## Client Delivery Phase 3
* Beta Level - ready for testing

*******


### Missing Stuff

* Documentation
* Help Files
* Source Code Management
* Specific requirement details ( like performance or system logging)




*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******
*******









**************************************************



## FROM OTHERS 

Users - UID, Username, Date, Contact Info

User_meta_keys - Meta Key ID, Key Name, Key Description

User_meta_values - Meta Value ID, Meta Key ID, UID, Meta Value, Date Set


