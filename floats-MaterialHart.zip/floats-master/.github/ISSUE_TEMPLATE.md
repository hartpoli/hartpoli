### This repository is no longer actively maintained.

Development of the packages in this repository has moved to https://github.com/gonum/gonum.
Please file issues [there](https://github.com/gonum/gonum/issues) after having checked that your issue has not been fixed.
