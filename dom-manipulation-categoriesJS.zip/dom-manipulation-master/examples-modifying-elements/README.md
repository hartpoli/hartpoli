# __Examples__: modifying elements

> [study these live](https://hackyourfuture.be/dom-manipulation/examples-modifying-elements)

* [remove a child](./remove-a-child.html)
* [`ul` to `ol`](./ul-to-ol.html)
* [update `ul`: manual](./update-ul-manual.html)
* [update `ul`: loop](./update-ul-loop.html)
* [update `ul`: forEach](./update-ul-forEach.html)
* [nested children 1](./nested-children-1.html)
* [nested children 2](./nested-children-2.html)
* [clone a node](./clone-a-node.html)
